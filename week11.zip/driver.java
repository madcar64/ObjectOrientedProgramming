import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.util.ArrayList;

// Person class
class Person implements Serializable{
	
	String name;
	String number;
	String dob;
	String email;
	
	// Default Constructor
	public Person() {
		name = "N/A";
		number = "N/A";
		dob = "N/A";
		email = "N/A";		
	}

	// Constructor
	public Person(String name, String number, String dob, String email) {
		super();
		this.name = name;
		this.number = number;
		this.dob = dob;
		this.email = email;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", number=" + number + ", dob=" + dob + ", email=" + email + "]";
	}
	
}
// Main class
public class driver {

	public static void main(String[] args) throws IOException, ClassNotFoundException
	{
		ArrayList<Person> people = new ArrayList<Person>();
		
		Person p1 = new Person("John","123-456-7890","1/1/60","john@mail.com");
		Person p2 = new Person("David","098-765-4321","6/5/76","david@mail.com");
		Person p3 = new Person("Alice","888-888-8888","4/5/55","alice@mail.com");
		Person p4 = new Person("George","111-111-1111","1/3/90","george@mail.com");
		Person p5 = new Person("Ralph","333-333-3333","10/31/93","ralph@mail.com");
		
		people.add(p1);
		people.add(p2);
		people.add(p3);
		people.add(p4);
		people.add(p5);
		
		writeToFile(people);
		
		readFile();
	}
	
	public static void writeToFile(ArrayList<Person> p) throws IOException{	
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("People.bin"));
		
		for (int i = 0; i < p.size(); i++)
		{			
			objectOutputStream.writeObject(p.get(i));			
		}

		objectOutputStream.close();

	}
	
	public static void readFile() throws IOException, ClassNotFoundException{
		ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("People.bin"));
		
		
		Person p = (Person) objectInputStream.readObject();

		System.out.println("1: " + p);
		
		p = (Person) objectInputStream.readObject();
		
		System.out.println("2: " + p);
	
		p = (Person) objectInputStream.readObject();
		
		System.out.println("3: " + p);
		
		p = (Person) objectInputStream.readObject();
		
		System.out.println("4: " + p);
		
		p = (Person) objectInputStream.readObject();
		
		System.out.println("5: " + p);
		
		objectInputStream.close();
		
	}
	
}